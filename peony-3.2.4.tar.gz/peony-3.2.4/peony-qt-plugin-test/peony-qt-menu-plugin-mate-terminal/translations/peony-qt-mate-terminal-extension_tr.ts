<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr_TR">
<context>
    <name>Peony::MateTerminalMenuPlugin</name>
    <message>
        <location filename="../mate-terminal-menu-plugin.cpp" line="44"/>
        <location filename="../mate-terminal-menu-plugin.cpp" line="53"/>
        <source>Open Directory in Terminal</source>
        <translation>Dizini Terminalde Aç</translation>
    </message>
    <message>
        <location filename="../mate-terminal-menu-plugin.h" line="22"/>
        <source>Peony-Qt Mate Terminal Menu Extension</source>
        <translation>Peony-Qt Mate Terminal Menü Eklentisi</translation>
    </message>
    <message>
        <location filename="../mate-terminal-menu-plugin.h" line="23"/>
        <source>Open Terminal with menu.</source>
        <translation>Terminali menü ile aç</translation>
    </message>
</context>
</TS>
